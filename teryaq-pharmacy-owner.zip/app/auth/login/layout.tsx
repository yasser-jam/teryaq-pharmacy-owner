export default function Home({ children }: { children: React.ReactElement }) {
  return <>{children}</>;
}
